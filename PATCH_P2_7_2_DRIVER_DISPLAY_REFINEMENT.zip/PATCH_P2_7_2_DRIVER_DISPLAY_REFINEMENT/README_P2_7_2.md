# P2.7.2 – Driver Display Refinement

Solo frontend. Nessuna migration database.

Modifiche:
- modalità guida compatta attivabile/disattivabile;
- layout landscape con delta dominante e pannelli secondari nascosti durante la guida;
- indicatore qualità GPS: OTTIMO / BUONO / DEBOLE / SCARSO;
- stato Start/Finish più chiaro;
- delta leggermente più grande.

File modificato:
- app/driver-display/page.tsx
